% Assignment 4 - Final Report 
% Phuc Toan Nguyen 
% SID:13671728
%% Clear and close 
close all 
clear all 
clc 
axis equal 

%% Puma 560 

%Robot 
mdl_puma560; 

%Base of the Robot 
p560.base = transl([1.367,1.728,1]); 
%Robot base is based on my SID:13671728 with this format [x.xxx,y.yyy,1] 

%Set up the tool on the p560
p560.tool = transl(0,0,0.2)*troty(-pi/4); 

% Angle Joints 
q_default = [0 pi/4 -pi 0 0 0]; % Using teach 
% q_default = [0 0 0 0 0 0];

%Plot robot 
p560.plot(q_default,'workspace',[0 3 0 3 0 2],'scale',0.5,'floorlevel',0);

hold on 

%Input the Drum model 
drum = plotObject_byTon(transl(2,1.5,0.35),trotx(0),'Drum.ply')

% 4 points on Drum 
%Using Tools -> Data Points
P1 = [2.095 1.685 0.6181]; 
P2 = [2.095 1.561 0.6181];
P3 = [1.905 1.561 0.6181];
P4 = [1.905 1.685 0.6181];
% 4x4 matrix format 
Point1 = [eye(3) P1'; zeros(1,3) 1]; 
Point2 = [eye(3) P2'; zeros(1,3) 1];
Point3 = [eye(3) P3'; zeros(1,3) 1];
Point4 = [eye(3) P4'; zeros(1,3) 1];

%Plot points for better observation 
plot3(Point1(1,4),Point1(2,4),Point1(3,4),'r.','MarkerSize', 15);
plot3(Point2(1,4),Point2(2,4),Point2(3,4),'g.','MarkerSize', 15);
plot3(Point3(1,4),Point3(2,4),Point2(3,4),'b.','MarkerSize', 15);
plot3(Point4(1,4),Point4(2,4),Point4(3,4),'y.','MarkerSize', 15);
% 
%Pose of the GitBlast based on each corners of the white window 
% Offset on X  axis of the EE to compensate for the offset of the gitblast 
% Rotate Pitch to make X point down (Comparing fkine of q default and point1 gitblast)
Point1_GitBlast = Point1*troty(pi/2)*transl(-0.2,0,0); 

%Inverse Kinematic to get the EE to the 4 points
q_Point1 = p560.ikcon(Point1_GitBlast,q_default); 

%Trajectory from q_default to Point1 
trajectory_QDtoP1 = jtraj(q_default,q_Point1,50);

%Animate from default joint angles to Point 1
for i =1:50
    p560.animate(trajectory_QDtoP1(i,:));
end

[qMatrix] = RMRC(p560,P1,P2,5,0.02); % t = 4s to break 
Dynamics_Torque(p560,qMatrix,5,0.02,2.14,214);%t = 5s for smooth motion 

disp("Grit blast is done");
%% RMRC function for grit blasting 
function [qMatrix] = RMRC(p560,startPoint, endPoint,time,dt)
    t = time;             % Total time (s)
    deltaT = dt;      % Control frequency
    steps = t/deltaT;   % No. of steps for simulation
    epsilon = 0.1;      % Threshold value for manipulability/Damped Least Squares. Should be 0.1 or less 
    W = diag([1 1 1 0.1 0.1 0.1]);   % Weighting matrix for the velocity vector

    m = zeros(steps,1);             % Array for Measure of Manipulability
    qMatrix = zeros(steps,6);       % Array for joint angles
    qdot = zeros(steps,6);          % Array for joint velocities
    x = zeros(3,steps);             % Array for x-y-z trajectory
    positionError = zeros(3,steps); % For plotting trajectory error
    angleError = zeros(3,steps);    % For plotting trajectory error

    s = lspb(0,1, steps);        % Trapezoidal trajectory scalar
    for i=1:steps
        x(1,i) = (1-s(i))*startPoint(1) + s(i)*endPoint(1);  % Points in x
        x(2,i) = (1-s(i))*startPoint(2) + s(i)*endPoint(2); % Points in y
        x(3,i) = (1-s(i))*(startPoint(3)+0.2) + s(i)*(endPoint(3)+0.2);     % Points in z
    end
    
    T = transl(x(1,1), x(1,2),x(1,3))* troty(pi/2);          % Create transformation of first point and angle                                                     % Initial guess for joint angles
    qMatrix(1,:) = p560.ikcon(T);  % Solve joint angles to achieve first waypoint
    for i = 1:steps-1
        T = p560.fkine(qMatrix(i,:));                       % Get forward transformation at current joint state
        deltaX = x(:,i+1) - T(1:3,4);                       % Get position error from next waypoint
        Rd = roty(pi/2);                                    % Get next RPY angles, convert to rotation matrix
        Ra = T(1:3,1:3);                                    % Current end-effector rotation matrix
        Rdot = (1/deltaT)*(Rd - Ra);                        % Calculate rotation matrix error (see RMRC lectures)
        S = Rdot*Ra';                                       % Skew symmetric!S(\omega)
        linear_velocity = (1/deltaT)*deltaX;
        angular_velocity = [S(3,2);S(1,3);S(2,1)];          % Check the structure of Skew Symmetric matrix!!(see RMRC lectures)
        deltaTheta = tr2rpy(Rd*Ra');                        % Convert rotation matrix to RPY angles
        xdot = W*[linear_velocity;angular_velocity];        % Calculate end-effector velocity to reach next waypoint.
        J = p560.jacob0(qMatrix(i,:));                      % Get Jacobian at current joint state
        m(i) = sqrt(det(J*J'));
        if m(i) < epsilon  % If manipulability is less than given threshold
            lambda = sqrt((1 - (m(i)/epsilon)^2)*(5E-2)^2);
        else
            lambda = 0;
        end
        invJ = inv(J'*J + lambda *eye(6))*J';               % DLS Inverse
        qdot(i,:) = (invJ*xdot)';                           % Solve the RMRC equation (you may need to transpose the vector)
        for j = 1:6                                         % Loop through joints 1 to 6
            if qMatrix(i,j) + deltaT*qdot(i,j) < p560.qlim(j,1) % If next joint angle is lower than joint limit...
                qdot(i,j) = 0; % Stop the motor
            elseif qMatrix(i,j) + deltaT*qdot(i,j) > p560.qlim(j,2)% If next joint angle is greater than joint limit ...
                qdot(i,j) = 0; % Stop the motor
            end
        end
        qMatrix(i+1,:) = qMatrix(i,:) + deltaT*qdot(i,:);  % Update next joint state based on joint velocities
        positionError(:,i) = x(:,i+1) - T(1:3,4);          % For plotting
        angleError(:,i) = deltaTheta;                      % For plotting
    end
    
%     Plot the results
    figure(1)
    plot3(x(1,:),x(2,:),x(3,:),'r','LineWidth',1)
    p560.plot(qMatrix,'trail','b-')
    
    for i = 1:6
        figure(2)
        subplot(3,2,i)
        plot(qMatrix(:,i),'k','LineWidth',1)
        title(['Joint ', num2str(i)])
        ylabel('Angle (rad)')
        refline(0,p560.qlim(i,1));
        refline(0,p560.qlim(i,2));

        figure(3)
        subplot(3,2,i)
        plot(qdot(:,i),'k','LineWidth',1)
        title(['Joint ',num2str(i)]);
        ylabel('Velocity (rad/s)')
        refline(0,0)
     end

     figure(4)
     subplot(2,1,1)
     plot(positionError'*1000,'LineWidth',1)
     refline(0,0)
     xlabel('Step')
     ylabel('Position Error (mm)')
     legend('X-Axis','Y-Axis','Z-Axis')
     subplot(2,1,2)
     plot(angleError','LineWidth',1)
     refline(0,0)
     xlabel('Step')
     ylabel('Angle Error (rad)')
     legend('Roll','Pitch','Yaw')
            
%      figure(5)
%      plot(m,'k','LineWidth',1)
%      refline(0,epsilon)
%      title('Manipulability')
end

%% Dynamics Torques 
function [] = Dynamics_Torque(p560,Matrix,time,deltat,mass,reaction_force) 
    tau_max = [97.6 186.4 89.4 24.2 20.1 21.3]';  
    dt = deltat; 
    steps = time/deltat; 
    s = lspb(0,1,steps);   
    Matrix_size = size(Matrix,1);
    % Generate trapezoidal velocity profile
    for i = 1:steps
        q(i,:) = (1-s(i))*Matrix(1,:) + s(i)*Matrix(Matrix_size,:);
    end
    
    qd = zeros(steps,6);                                                        % Array of joint velocities
    qdd = nan(steps,6);                                                         % Array of joint accelerations
    tau = nan(steps,6);
    total_force = mass*9.81 - reaction_force; 
    payload = total_force/9.81; 
    p560.payload(payload,[0,0,0]);
    
    for i = 1:steps-1
        qdd(i,:) = (1/dt)^2 * (q(i+1,:) - q(i,:) - dt*qd(i,:));                 % Calculate joint acceleration to get to next set of joint angles
        M = p560.inertia(q(i,:));                                               % Calculate inertia matrix at this pose
        C = p560.coriolis(q(i,:),qd(i,:));                                      % Calculate coriolis matrix at this pose
        g = p560.gravload(q(i,:));                                              % Calculate gravity vector at this pose
        tau(i,:) = (M*qdd(i,:)' + C*qd(i,:)' + g')';                            % Calculate the joint torque needed

        qdd(i,:) = (inv(M)*(tau(i,:)' - C*qd(i,:)' - g'))';                     % Re-calculate acceleration based on actual torque
        q(i+1,:) = q(i,:) + dt*qd(i,:) + dt^2*qdd(i,:);                         % Update joint angles based on actual acceleration
        qd(i+1,:) = qd(i,:) + dt*qdd(i,:);                                      % Update the velocity for the next pose
    end 

    t = 0:dt:(steps-1)*dt; 

    % Plot joint angles
    figure(5)
    for j = 1:6
        subplot(3,2,j)
        plot(t,q(:,j)','k','LineWidth',1);
        refline(0,p560.qlim(j,1));
        refline(0,p560.qlim(j,2));
        ylabel('Angle (rad)');
        box off
    end

    % Plot joint velocities
    figure(6)
    for j = 1:6
        subplot(3,2,j)
        plot(t,qd(:,j)*30/pi,'k','LineWidth',1);
        refline(0,0);
        ylabel('Velocity (RPM)');
        box off
    end

    % Plot joint acceleration
    figure(7)
    for j = 1:6
        subplot(3,2,j)
        plot(t,qdd(:,j),'k','LineWidth',1);
        ylabel('rad/s/s');
        refline(0,0)
        box off
    end

    % Plot joint torques
    figure(8)
    for j = 1:6
        subplot(3,2,j)
        plot(t,tau(:,j),'k','LineWidth',1);
        refline(0,tau_max(j));
        refline(0,-tau_max(j));
        ylabel('Nm');
        box off
    end
end
